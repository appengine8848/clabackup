interface ImportMetaEnv {
  readonly version: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
